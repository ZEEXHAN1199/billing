// Import modules
import { initDB } from './db.js';
import { loadModule } from './modules/module-loader.js';
import { setupDarkMode } from './dark-mode.js';

// Initialize application
document.addEventListener('DOMContentLoaded', async () => {
  // Initialize database
  await initDB();
  
  // Load header and sidebar
  await loadTemplate('header', 'templates/header.html');
  await loadTemplate('sidebar', 'templates/sidebar.html');
  
  // Load default module (dashboard)
  await loadModule('dashboard');
  
  // Setup dark mode
  setupDarkMode();
  
  // Setup event listeners
  setupEventListeners();
});

// Load HTML templates
async function loadTemplate(elementId, templatePath) {
  try {
    const response = await fetch(templatePath);
    const html = await response.text();
    document.getElementById(elementId).innerHTML = html;
  } catch (error) {
    console.error(`Error loading template ${templatePath}:`, error);
  }
}

// Setup global event listeners
function setupEventListeners() {
  // Sidebar navigation
  document.addEventListener('click', (e) => {
    if (e.target.closest('.sidebar-item')) {
      e.preventDefault();
      const module = e.target.closest('.sidebar-item').dataset.module;
      loadModule(module);
    }
  });
  
  // Dark mode toggle
  document.getElementById('darkModeSwitch')?.addEventListener('change', toggleDarkMode);
}
import { addRecord, getAllRecords } from '../../js/db.js';

export async function initCashflow() {
  // Load transactions from database
  const transactions = await getAllRecords('transactions');
  renderTransactions(transactions);
  
  // Setup event listeners
  document.getElementById('addTransactionForm').addEventListener('submit', handleAddTransaction);
}

function renderTransactions(transactions) {
  const tableBody = document.querySelector('#transactions-table tbody');
  tableBody.innerHTML = transactions.map(transaction => `
    <tr>
      <td>${formatDate(transaction.date)}</td>
      <td>${transaction.description}</td>
      <td>${transaction.category}</td>
      <td>${formatCurrency(transaction.amount)}</td>
      <td><span class="badge ${transaction.type === 'income' ? 'bg-success' : 'bg-danger'}">${transaction.type}</span></td>
      <td>
        <button class="btn btn-sm btn-outline-secondary edit-btn" data-id="${transaction.id}">
          <i class="bi bi-pencil"></i>
        </button>
        <button class="btn btn-sm btn-outline-danger delete-btn" data-id="${transaction.id}">
          <i class="bi bi-trash"></i>
        </button>
      </td>
    </tr>
  `).join('');
  
  // Add event listeners to buttons
  document.querySelectorAll('.edit-btn').forEach(btn => {
    btn.addEventListener('click', handleEditTransaction);
  });
  
  document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', handleDeleteTransaction);
  });
}

async function handleAddTransaction(e) {
  e.preventDefault();
  
  const form = e.target;
  const formData = new FormData(form);
  
  const transaction = {
    date: formData.get('date'),
    description: formData.get('description'),
    amount: parseFloat(formData.get('amount')),
    category: formData.get('category'),
    type: formData.get('type')
  };
  
  try {
    await addRecord('transactions', transaction);
    form.reset();
    bootstrap.Modal.getInstance(document.getElementById('addTransactionModal')).hide();
    initCashflow(); // Refresh the list
  } catch (error) {
    console.error('Error adding transaction:', error);
    alert('Failed to add transaction');
  }
}
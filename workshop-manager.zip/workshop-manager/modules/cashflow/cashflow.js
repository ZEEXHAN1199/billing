import { 
    getAllRecords, 
    getRecordsByDateRange, 
    addRecord, 
    updateRecord,
    deleteRecord 
  } from '../../js/db.js';
  import { formatCurrency, formatDate } from '../../js/utils.js';
  import { showNotification } from '../../js/notifications.js';
  import { exportToPDF, exportToExcel } from '../../js/export.js';
  import Chart from 'chart.js/auto';
  
  // Initialize cash flow module
  export async function initCashflow() {
    // Load initial data
    await loadCashflowData();
    
    // Initialize charts
    initForecastChart();
    
    // Setup event listeners
    setupCashflowEventListeners();
    
    // Check for due recurring transactions
    checkRecurringTransactions();
  }
  
  async function loadCashflowData() {
    try {
      // Get current date range (default to this month)
      const dateRange = getDateRange('month');
      
      // Load transactions, customers, suppliers, and recurring transactions
      const [transactions, customers, suppliers, recurring] = await Promise.all([
        getRecordsByDateRange('transactions', dateRange.start, dateRange.end),
        getAllRecords('customers'),
        getAllRecords('suppliers'),
        getAllRecords('recurring_transactions')
      ]);
      
      // Render all data
      renderTransactions(transactions);
      renderLedgers([...customers, ...suppliers]);
      renderRecurringTransactions(recurring);
      updateSummaryCards(transactions);
      
    } catch (error) {
      console.error('Error loading cash flow data:', error);
      showNotification('Failed to load cash flow data', 'danger');
    }
  }
  
  function renderTransactions(transactions) {
    const tableBody = document.querySelector('#transactions-table tbody');
    
    tableBody.innerHTML = transactions.map(transaction => {
      const isIncome = transaction.type === 'income';
      const typeClass = isIncome ? 'text-success' : 'text-danger';
      const typeText = isIncome ? 'Income' : 'Expense';
      
      const receiptThumb = transaction.receipt ? `
        <img src="${transaction.receipt.thumbnail || transaction.receipt.url}" 
             class="receipt-thumbnail" 
             data-receipt="${transaction.receipt.url}"
             data-bs-toggle="tooltip" 
             title="View receipt">
      ` : '-';
      
      return `
        <tr data-id="${transaction.id}">
          <td>${formatDate(transaction.date)}</td>
          <td>${transaction.description || '-'}</td>
          <td>${transaction.party || '-'}</td>
          <td>${transaction.category || '-'}</td>
          <td class="${typeClass}">${formatCurrency(transaction.amount)}</td>
          <td><span class="badge ${isIncome ? 'bg-success' : 'bg-danger'}">${typeText}</span></td>
          <td>${receiptThumb}</td>
          <td>
            <button class="btn btn-sm btn-outline-secondary me-1 edit-transaction">
              <i class="bi bi-pencil"></i>
            </button>
            <button class="btn btn-sm btn-outline-danger delete-transaction">
              <i class="bi bi-trash"></i>
            </button>
          </td>
        </tr>
      `;
    }).join('');
    
    // Update transaction count
    document.getElementById('transaction-count').textContent = 
      `Showing ${transactions.length} transactions`;
    
    // Initialize receipt viewer tooltips
    $('[data-bs-toggle="tooltip"]').tooltip();
  }
  
  function renderLedgers(parties) {
    const tableBody = document.querySelector('#ledger-table tbody');
    
    tableBody.innerHTML = parties.map(party => {
      const typeText = party.type === 'customer' ? 'Customer' : 'Supplier';
      const typeClass = party.type === 'customer' ? 'bg-info' : 'bg-warning';
      
      // Calculate ledger status (simplified for example)
      const balance = party.balance || 0;
      let statusClass, statusText;
      
      if (balance === 0) {
        statusClass = 'status-current';
        statusText = 'Current';
      } else if (balance > 0 && party.type === 'customer') {
        statusClass = 'status-overdue';
        statusText = 'Overdue';
      } else if (balance < 0 && party.type === 'supplier') {
        statusClass = 'status-overdue';
        statusText = 'Due';
      } else {
        statusClass = 'status-current';
        statusText = 'Current';
      }
      
      return `
        <tr data-id="${party.id}" data-type="${party.type}">
          <td>${party.name}</td>
          <td><span class="badge ${typeClass}">${typeText}</span></td>
          <td class="${balance !== 0 ? 'fw-bold' : ''}">
            ${formatCurrency(Math.abs(balance))} ${balance > 0 ? 'Due' : 'Credit'}
          </td>
          <td>${party.lastTransaction ? formatDate(party.lastTransaction) : 'Never'}</td>
          <td><span class="ledger-status ${statusClass}">${statusText}</span></td>
          <td>
            <button class="btn btn-sm btn-outline-primary view-ledger">
              <i class="bi bi-journal-text"></i> View
            </button>
          </td>
        </tr>
      `;
    }).join('');
    
    // Update ledger count
    document.getElementById('ledger-count').textContent = 
      `Showing ${parties.length} ledgers`;
  }
  
  function renderRecurringTransactions(recurringTransactions) {
    const tableBody = document.querySelector('#recurring-table tbody');
    
    tableBody.innerHTML = recurringTransactions.map(rt => {
      const isActive = rt.status === 'active';
      const statusClass = isActive ? 'recurring-active' : 
        rt.status === 'paused' ? 'recurring-paused' : 'recurring-ended';
      
      return `
        <tr data-id="${rt.id}">
          <td>${rt.description || 'Recurring Transaction'}</td>
          <td>${rt.frequency}</td>
          <td>${formatCurrency(rt.amount)}</td>
          <td>${rt.nextDate ? formatDate(rt.nextDate) : '-'}</td>
          <td>${rt.category || '-'}</td>
          <td><span class="${statusClass}">${rt.status}</span></td>
          <td>
            <button class="btn btn-sm btn-outline-secondary me-1 edit-recurring">
              <i class="bi bi-pencil"></i>
            </button>
            <button class="btn btn-sm btn-outline-danger delete-recurring">
              <i class="bi bi-trash"></i>
            </button>
          </td>
        </tr>
      `;
    }).join('');
    
    // Update recurring count
    document.getElementById('recurring-count').textContent = 
      `Showing ${recurringTransactions.length} recurring transactions`;
  }
  
  function updateSummaryCards(transactions) {
    // Calculate totals
    const income = transactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);
    
    const expenses = transactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);
    
    const netCashflow = income - expenses;
    
    // Update UI
    document.getElementById('total-income').textContent = formatCurrency(income);
    document.getElementById('total-expenses').textContent = formatCurrency(expenses);
    document.getElementById('net-cashflow').textContent = formatCurrency(netCashflow);
    
    // Update progress bars (simplified for example)
    document.querySelector('#total-income + .progress .progress-bar').style.width = 
      `${Math.min(100, (income / 15000) * 100)}%`;
    document.querySelector('#total-expenses + .progress .progress-bar').style.width = 
      `${Math.min(100, (expenses / 7000) * 100)}%`;
    document.querySelector('#net-cashflow + .progress .progress-bar').style.width = 
      `${Math.min(100, (netCashflow / 8000) * 100)}%`;
  }
  
  function initForecastChart() {
    const ctx = document.getElementById('forecastChart').getContext('2d');
    
    // Sample forecast data (in a real app, this would be calculated)
    const labels = [];
    const today = new Date();
    
    for (let i = 1; i <= 12; i++) {
      const date = new Date(today);
      date.setMonth(today.getMonth() + i);
      labels.push(date.toLocaleDateString('en', { month: 'short', year: 'numeric' }));
    }
    
    const incomeData = labels.map((_, i) => 10000 + (Math.random() * 5000 * i));
    const expenseData = labels.map((_, i) => 5000 + (Math.random() * 3000 * i));
    
    // Create chart
    window.forecastChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [
          {
            label: 'Projected Income',
            data: incomeData,
            backgroundColor: 'rgba(52, 199, 89, 0.7)',
            borderColor: 'rgba(52, 199, 89, 1)',
            borderWidth: 1
          },
          {
            label: 'Projected Expenses',
            data: expenseData,
            backgroundColor: 'rgba(255, 59, 48, 0.7)',
            borderColor: 'rgba(255, 59, 48, 1)',
            borderWidth: 1
          },
          {
            label: 'Net Cash Flow',
            data: labels.map((_, i) => incomeData[i] - expenseData[i]),
            type: 'line',
            borderColor: 'rgba(0, 113, 227, 1)',
            backgroundColor: 'transparent',
            borderWidth: 2,
            pointBackgroundColor: 'rgba(0, 113, 227, 1)'
          }
        ]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'top',
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                return `${context.dataset.label}: ${formatCurrency(context.raw)}`;
              }
            }
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              callback: function(value) {
                return formatCurrency(value);
              }
            }
          }
        }
      }
    });
    
    // Update forecast summary
    const totalIncome = incomeData.reduce((sum, val) => sum + val, 0) / 12;
    const totalExpenses = expenseData.reduce((sum, val) => sum + val, 0) / 12;
    const netCashflow = totalIncome - totalExpenses;
    
    document.getElementById('forecast-income').textContent = formatCurrency(totalIncome);
    document.getElementById('forecast-expenses').textContent = formatCurrency(totalExpenses);
    document.getElementById('forecast-net').textContent = formatCurrency(netCashflow);
  }
  
  function setupCashflowEventListeners() {
    // Period selector
    document.getElementById('cashflow-period').addEventListener('click', function() {
      const periods = ['day', 'week', 'month', 'quarter', 'year'];
      const currentIndex = periods.indexOf(this.dataset.period);
      const nextIndex = (currentIndex + 1) % periods.length;
      const nextPeriod = periods[nextIndex];
      
      this.dataset.period = nextPeriod;
      this.innerHTML = `
        <i class="bi bi-calendar me-1"></i> This ${nextPeriod.charAt(0).toUpperCase() + nextPeriod.slice(1)}
      `;
      
      loadCashflowData();
    });
    
    // Forecast period buttons
    document.querySelectorAll('#forecast-period').forEach(btn => {
      btn.addEventListener('click', function() {
        document.querySelectorAll('#forecast-period').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        updateForecastChart(parseInt(this.dataset.period));
      });
    });
    
    // Transaction filters
    document.querySelectorAll('.filter-option').forEach(option => {
      option.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelectorAll('.filter-option').forEach(o => o.classList.remove('active'));
        this.classList.add('active');
        filterTransactions(this.dataset.type, this.dataset.category);
      });
    });
    
    // Ledger filters
    document.querySelectorAll('[data-ledger-type]').forEach(option => {
      option.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelectorAll('[data-ledger-type]').forEach(o => o.classList.remove('active'));
        this.classList.add('active');
        filterLedgers(this.dataset.ledgerType);
      });
    });
    
    // Search functionality
    document.getElementById('transaction-search').addEventListener('input', function() {
      searchTransactions(this.value);
    });
    
    document.getElementById('ledger-search').addEventListener('input', function() {
      searchLedgers(this.value);
    });
    
    // Add transaction form
    document.getElementById('makeRecurring').addEventListener('change', function() {
      document.getElementById('recurringOptions').style.display = this.checked ? 'block' : 'none';
    });
    
    document.getElementById('applyDiscount').addEventListener('click', function() {
      const amount = parseFloat(document.getElementById('transactionAmount').value) || 0;
      const discount = parseFloat(document.getElementById('transactionDiscount').value) || 0;
      
      if (discount > 0 && discount <= amount) {
        document.getElementById('transactionAmount').value = (amount - discount).toFixed(2);
        showNotification(`Discount of ${formatCurrency(discount)} applied`, 'success');
      } else {
        showNotification('Invalid discount amount', 'danger');
      }
    });
    
    document.getElementById('saveTransaction').addEventListener('click', async function() {
      const form = document.getElementById('transactionForm');
      if (!form.checkValidity()) {
        form.classList.add('was-validated');
        return;
      }
      
      const transaction = {
        date: document.getElementById('transactionDate').value,
        type: document.querySelector('input[name="transactionType"]:checked').value,
        party: document.getElementById('transactionParty').value,
        category: document.getElementById('transactionCategory').value,
        amount: parseFloat(document.getElementById('transactionAmount').value),
        description: document.getElementById('transactionDescription').value,
        discount: parseFloat(document.getElementById('transactionDiscount').value) || 0,
        receipt: null // Would be set from file upload
      };
      
      if (document.getElementById('makeRecurring').checked) {
        const recurring = {
          ...transaction,
          frequency: document.getElementById('recurringFrequency').value,
          startDate: document.getElementById('recurringStartDate').value,
          endDate: document.getElementById('recurringEndDate').value || null,
          status: 'active',
          nextDate: calculateNextDate(
            document.getElementById('recurringFrequency').value,
            document.getElementById('recurringStartDate').value
          )
        };
        
        await addRecord('recurring_transactions', recurring);
        showNotification('Recurring transaction created successfully', 'success');
      } else {
        await addRecord('transactions', transaction);
        showNotification('Transaction recorded successfully', 'success');
      }
      
      // Refresh data and close modal
      loadCashflowData();
      bootstrap.Modal.getInstance(document.getElementById('addTransactionModal')).hide();
    });
    
    // Ledger actions
    document.addEventListener('click', function(e) {
      if (e.target.closest('.view-ledger')) {
        const row = e.target.closest('tr');
        const ledgerId = row.dataset.id;
        const ledgerType = row.dataset.type;
        viewLedgerDetails(ledgerId, ledgerType);
      }
    });
    
    // Receipt viewer
    document.addEventListener('click', function(e) {
      if (e.target.classList.contains('receipt-thumbnail')) {
        const receiptUrl = e.target.dataset.receipt;
        viewReceipt(receiptUrl);
      }
    });
    
    // Export buttons
    document.getElementById('export-forecast').addEventListener('click', exportForecastReport);
    document.getElementById('printLedger').addEventListener('click', printLedger);
    document.getElementById('exportLedger').addEventListener('click', exportLedger);
    
    // Recurring transactions
    document.getElementById('run-recurring').addEventListener('click', processDueRecurringTransactions);
  }
  
  function filterTransactions(type, category) {
    const rows = document.querySelectorAll('#transactions-table tbody tr');
    
    rows.forEach(row => {
      const rowType = row.querySelector('td:nth-child(6)').textContent.toLowerCase();
      const rowCategory = row.querySelector('td:nth-child(4)').textContent.toLowerCase();
      
      const typeMatch = type === 'all' || 
        (type === 'income' && rowType === 'income') || 
        (type === 'expense' && rowType === 'expense');
      
      const categoryMatch = !category || rowCategory.includes(category.toLowerCase());
      
      row.style.display = typeMatch && categoryMatch ? '' : 'none';
    });
  }
  
  function filterLedgers(type) {
    const rows = document.querySelectorAll('#ledger-table tbody tr');
    
    rows.forEach(row => {
      const rowType = row.dataset.type;
      
      const typeMatch = type === 'all' || 
        (type === 'customers' && rowType === 'customer') || 
        (type === 'suppliers' && rowType === 'supplier');
      
      row.style.display = typeMatch ? '' : 'none';
    });
  }
  
  function searchTransactions(query) {
    const rows = document.querySelectorAll('#transactions-table tbody tr');
    const lowerQuery = query.toLowerCase();
    
    rows.forEach(row => {
      const text = row.textContent.toLowerCase();
      row.style.display = text.includes(lowerQuery) ? '' : 'none';
    });
  }
  
  function searchLedgers(query) {
    const rows = document.querySelectorAll('#ledger-table tbody tr');
    const lowerQuery = query.toLowerCase();
    
    rows.forEach(row => {
      const text = row.textContent.toLowerCase();
      row.style.display = text.includes(lowerQuery) ? '' : 'none';
    });
  }
  
  function updateForecastChart(days) {
    if (!window.forecastChart) return;
    
    // Update chart with new time period (simplified for example)
    const labels = [];
    const today = new Date();
    
    for (let i = 1; i <= Math.ceil(days / 30); i++) {
      const date = new Date(today);
      date.setMonth(today.getMonth() + i);
      labels.push(date.toLocaleDateString('en', { month: 'short', year: 'numeric' }));
    }
    
    const incomeData = labels.map((_, i) => 10000 + (Math.random() * 5000 * i));
    const expenseData = labels.map((_, i) => 5000 + (Math.random() * 3000 * i));
    
    window.forecastChart.data.labels = labels;
    window.forecastChart.data.datasets[0].data = incomeData;
    window.forecastChart.data.datasets[1].data = expenseData;
    window.forecastChart.data.datasets[2].data = labels.map((_, i) => incomeData[i] - expenseData[i]);
    window.forecastChart.update();
    
    // Update forecast summary
    const totalIncome = incomeData.reduce((sum, val) => sum + val, 0) / incomeData.length;
    const totalExpenses = expenseData.reduce((sum, val) => sum + val, 0) / expenseData.length;
    const netCashflow = totalIncome - totalExpenses;
    
    document.getElementById('forecast-income').textContent = formatCurrency(totalIncome);
    document.getElementById('forecast-expenses').textContent = formatCurrency(totalExpenses);
    document.getElementById('forecast-net').textContent = formatCurrency(netCashflow);
  }
  
  async function viewLedgerDetails(ledgerId, ledgerType) {
    // In a real app, this would fetch ledger details from the database
    const ledger = {
      id: ledgerId,
      name: ledgerType === 'customer' ? 'John Doe' : 'Acme Supplies',
      type: ledgerType,
      balance: ledgerType === 'customer' ? 1250.50 : -750.25,
      transactions: [
        {
          date: '2023-05-15',
          description: 'Custom Table Order',
          reference: 'INV-1001',
          billed: 1500.00,
          paid: 1250.50,
          discount: 249.50,
          balance: 0,
          receipt: null
        },
        {
          date: '2023-04-20',
          description: 'Bookshelf Order',
          reference: 'INV-998',
          billed: 750.00,
          paid: 750.00,
          discount: 0,
          balance: 0,
          receipt: null
        }
      ]
    };
    
    // Update modal title
    document.getElementById('ledgerModalTitle').textContent = 
      `${ledgerType.charAt(0).toUpperCase() + ledgerType.slice(1)} Ledger - ${ledger.name}`;
    
    // Update summary
    document.getElementById('ledger-total-billed').textContent = 
      formatCurrency(ledger.transactions.reduce((sum, t) => sum + t.billed, 0));
    document.getElementById('ledger-total-paid').textContent = 
      formatCurrency(ledger.transactions.reduce((sum, t) => sum + t.paid, 0));
    document.getElementById('ledger-total-discounts').textContent = 
      formatCurrency(ledger.transactions.reduce((sum, t) => sum + t.discount, 0));
    document.getElementById('ledger-current-balance').textContent = 
      formatCurrency(ledger.balance);
    
    // Update transactions table
    const tableBody = document.querySelector('#ledger-transactions-table tbody');
    tableBody.innerHTML = ledger.transactions.map(t => `
      <tr>
        <td>${formatDate(t.date)}</td>
        <td>${t.description}</td>
        <td>${t.reference}</td>
        <td>${formatCurrency(t.billed)}</td>
        <td>${formatCurrency(t.paid)}</td>
        <td>${formatCurrency(t.discount)}</td>
        <td>${formatCurrency(t.balance)}</td>
        <td>${t.receipt ? 'Yes' : 'No'}</td>
      </tr>
    `).join('');
    
    // Set up settlement form
    document.getElementById('settleAmount').value = Math.abs(ledger.balance).toFixed(2);
    document.getElementById('settleDiscount').value = '0.00';
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('ledgerDetailModal'));
    modal.show();
  }
  
  function viewReceipt(receiptUrl) {
    const modal = new bootstrap.Modal(document.getElementById('receiptViewerModal'));
    
    // Check if it's an image or PDF
    if (receiptUrl.toLowerCase().endsWith('.pdf')) {
      document.getElementById('receipt-image').style.display = 'none';
      document.getElementById('receipt-pdf-viewer').style.display = 'block';
      
      // In a real app, you would use a PDF viewer library like PDF.js
      document.getElementById('receipt-pdf-viewer').innerHTML = `
        <div class="alert alert-info">
          PDF Viewer would display here in a production app
        </div>
        <p class="text-muted">File: ${receiptUrl.split('/').pop()}</p>
      `;
    } else {
      document.getElementById('receipt-image').style.display = 'block';
      document.getElementById('receipt-pdf-viewer').style.display = 'none';
      document.getElementById('receipt-image').src = receiptUrl;
    }
    
    // Set up download button
    document.getElementById('downloadReceipt').onclick = function() {
      const link = document.createElement('a');
      link.href = receiptUrl;
      link.download = receiptUrl.split('/').pop();
      link.click();
    };
    
    modal.show();
  }
  
  function calculateNextDate(frequency, startDate) {
    const date = new Date(startDate);
    
    switch(frequency) {
      case 'weekly':
        date.setDate(date.getDate() + 7);
        break;
      case 'biweekly':
        date.setDate(date.getDate() + 14);
        break;
      case 'monthly':
        date.setMonth(date.getMonth() + 1);
        break;
      case 'quarterly':
        date.setMonth(date.getMonth() + 3);
        break;
      case 'yearly':
        date.setFullYear(date.getFullYear() + 1);
        break;
    }
    
    return date.toISOString().split('T')[0];
  }
  
  async function checkRecurringTransactions() {
    const today = new Date().toISOString().split('T')[0];
    const recurring = await getAllRecords('recurring_transactions');
    
    const dueTransactions = recurring.filter(rt => 
      rt.status === 'active' && 
      rt.nextDate && 
      rt.nextDate <= today
    );
    
    if (dueTransactions.length > 0) {
      showNotification(
        `${dueTransactions.length} recurring transactions due for processing`,
        'warning'
      );
    }
  }
  
  async function processDueRecurringTransactions() {
    const today = new Date().toISOString().split('T')[0];
    const recurring = await getAllRecords('recurring_transactions');
    
    const dueTransactions = recurring.filter(rt => 
      rt.status === 'active' && 
      rt.nextDate && 
      rt.nextDate <= today
    );
    
    if (dueTransactions.length === 0) {
      showNotification('No recurring transactions due for processing', 'info');
      return;
    }
    
    // Process each due transaction
    for (const rt of dueTransactions) {
      // Create the transaction
      const transaction = {
        date: rt.nextDate,
        type: rt.type,
        party: rt.party,
        category: rt.category,
        amount: rt.amount,
        description: rt.description,
        discount: rt.discount || 0,
        receipt: null,
        recurringId: rt.id
      };
      
      await addRecord('transactions', transaction);
      
      // Update the recurring transaction with next date
      if (!rt.endDate || new Date(rt.nextDate) < new Date(rt.endDate)) {
        rt.nextDate = calculateNextDate(rt.frequency, rt.nextDate);
        await updateRecord('recurring_transactions', rt);
      } else {
        rt.status = 'ended';
        await updateRecord('recurring_transactions', rt);
      }
    }
    
    showNotification(
      `Processed ${dueTransactions.length} recurring transactions`,
      'success'
    );
    
    // Refresh the data
    loadCashflowData();
  }
  
  async function exportForecastReport() {
    try {
      // Get forecast data
      const forecastData = {
        period: document.querySelector('#forecast-period.active').dataset.period,
        income: document.getElementById('forecast-income').textContent,
        expenses: document.getElementById('forecast-expenses').textContent,
        net: document.getElementById('forecast-net').textContent,
        chartData: window.forecastChart.data
      };
      
      // Generate PDF
      await exportToPDF({
        title: 'Cash Flow Forecast Report',
        content: forecastData,
        type: 'forecast'
      });
      
      showNotification('Forecast report exported successfully', 'success');
    } catch (error) {
      console.error('Error exporting forecast:', error);
      showNotification('Failed to export forecast report', 'danger');
    }
  }
  
  async function printLedger() {
    try {
      // In a real app, this would generate a printer-friendly version of the ledger
      showNotification('Preparing ledger for printing...', 'info');
      
      // Simulate print delay
      setTimeout(() => {
        window.print();
      }, 1000);
    } catch (error) {
      console.error('Error printing ledger:', error);
      showNotification('Failed to print ledger', 'danger');
    }
  }
  
  async function exportLedger() {
    try {
      // In a real app, this would export the current ledger view
      const ledgerData = {
        // Would contain the current ledger's data
      };
      
      await exportToExcel([ledgerData], 'Ledger_Export');
      
      showNotification('Ledger exported successfully', 'success');
    } catch (error) {
      console.error('Error exporting ledger:', error);
      showNotification('Failed to export ledger', 'danger');
    }
  }
  
  function getDateRange(period) {
    const now = new Date();
    const start = new Date(now);
    const end = new Date(now);
    
    switch(period) {
      case 'day':
        start.setHours(0, 0, 0, 0);
        end.setHours(23, 59, 59, 999);
        break;
      case 'week':
        start.setDate(now.getDate() - now.getDay());
        start.setHours(0, 0, 0, 0);
        end.setDate(start.getDate() + 6);
        end.setHours(23, 59, 59, 999);
        break;
      case 'month':
        start.setDate(1);
        start.setHours(0, 0, 0, 0);
        end.setMonth(start.getMonth() + 1, 0);
        end.setHours(23, 59, 59, 999);
        break;
      case 'quarter':
        const quarter = Math.floor(now.getMonth() / 3);
        start.setMonth(quarter * 3, 1);
        start.setHours(0, 0, 0, 0);
        end.setMonth(start.getMonth() + 3, 0);
        end.setHours(23, 59, 59, 999);
        break;
      case 'year':
        start.setMonth(0, 1);
        start.setHours(0, 0, 0, 0);
        end.setMonth(11, 31);
        end.setHours(23, 59, 59, 999);
        break;
      default: // month
        start.setDate(1);
        start.setHours(0, 0, 0, 0);
        end.setMonth(start.getMonth() + 1, 0);
        end.setHours(23, 59, 59, 999);
    }
    
    return { start, end };
  }
import { getAllRecords, getRecordsByDateRange } from '../../js/db.js';
import Chart from 'chart.js/auto';
import { formatCurrency, formatDate } from '../../js/utils.js';
import { showNotification } from '../../js/notifications.js';
import { exportToPDF, exportToExcel, exportToCSV } from '../../js/export.js';
import { initDateRangePicker } from '../../js/datepicker.js';

// Dashboard state
let dashboardState = {
  currentDateRange: 'month',
  customerSegment: 'all',
  projectFilter: 'all',
  projectType: 'all',
  lastUpdated: null,
  socket: null,
  refreshInterval: null
};

// Initialize dashboard
export async function initDashboard() {
  // Initialize date range picker
  await initDateRangePicker('date-range-picker-container', handleDateRangeChange);
  
  // Load initial data
  await refreshDashboardData();
  
  // Initialize real-time updates
  initRealTimeUpdates();
  
  // Setup event listeners
  setupDashboardEventListeners();
  
  // Check for milestones
  checkForMilestones();
}

async function refreshDashboardData(showLoading = true) {
  if (showLoading) {
    showLoadingIndicator();
  }
  
  try {
    // Get date range for filters
    const dateRange = getDateRange(dashboardState.currentDateRange);
    
    // Load data with current filters
    const [transactions, projects, inventory, customers] = await Promise.all([
      getRecordsByDateRange('transactions', dateRange.start, dateRange.end),
      getFilteredProjects(),
      getAllRecords('inventory'),
      getFilteredCustomers()
    ]);
    
    // Calculate and render metrics
    calculateFinancialKPIs(transactions);
    calculateCustomerMetrics(customers, projects);
    calculateInventoryMetrics(inventory);
    renderInventoryLevels(inventory);
    renderProjectStatus(projects);
    
    // Initialize/update charts
    initFinancialChart(transactions, customers);
    initCustomerChart(customers);
    
    // Update last updated time
    dashboardState.lastUpdated = new Date();
    updateLastUpdatedTime();
    
    // Check for critical notifications
    checkForCriticalNotifications(inventory, projects);
    
  } catch (error) {
    console.error('Error refreshing dashboard:', error);
    showNotification('Error loading dashboard data', 'danger');
  } finally {
    if (showLoading) {
      hideLoadingIndicator();
    }
  }
}

function initRealTimeUpdates() {
  // In a real app, this would use WebSockets for live updates
  // For this example, we'll simulate with periodic refreshes
  
  // Clear any existing interval
  if (dashboardState.refreshInterval) {
    clearInterval(dashboardState.refreshInterval);
  }
  
  // Set up new interval (every 2 minutes)
  dashboardState.refreshInterval = setInterval(() => {
    refreshDashboardData(false);
  }, 120000);
  
  // Simulate real-time updates with random data changes
  simulateRealTimeData();
}

function simulateRealTimeData() {
  // This is just for demonstration - in a real app you'd have actual real-time updates
  setInterval(() => {
    // Randomly update some metrics
    if (Math.random() > 0.7) {
      const netProfitElement = document.getElementById('net-profit');
      if (netProfitElement) {
        const current = parseInt(netProfitElement.textContent.replace(/[^0-9]/g, ''));
        const change = Math.floor(Math.random() * 200) - 100;
        const newValue = Math.max(0, current + change);
        netProfitElement.textContent = formatCurrency(newValue);
        
        // Show a notification for large changes
        if (Math.abs(change) > 50) {
          const direction = change > 0 ? 'up' : 'down';
          showNotification(`Net profit ${direction} by ${formatCurrency(Math.abs(change))}`, 
                          direction === 'up' ? 'success' : 'danger');
        }
      }
    }
  }, 30000);
}

function calculateFinancialKPIs(transactions) {
  // Calculate revenue
  const revenue = transactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);
  
  // Calculate expenses
  const expenses = transactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);
  
  // Calculate KPIs
  const grossProfit = revenue;
  const netProfit = revenue - expenses;
  const expensesRatio = revenue ? (expenses / revenue) * 100 : 0;
  
  // Get comparison data for previous period
  const comparison = getComparisonData();
  
  // Update UI
  document.getElementById('gross-profit').textContent = formatCurrency(grossProfit);
  document.getElementById('net-profit').textContent = formatCurrency(netProfit);
  document.getElementById('expenses-ratio').textContent = `${expensesRatio.toFixed(1)}%`;
  
  // Update comparison indicators
  updateComparisonIndicator('gross-profit-change', grossProfit, comparison.lastRevenue);
  updateComparisonIndicator('net-profit-change', netProfit, comparison.lastNetProfit);
  updateComparisonIndicator('expenses-ratio-change', expensesRatio, comparison.lastExpensesRatio, true);
}

function calculateCustomerMetrics(customers, projects) {
  // Calculate new customers
  const newCustomers = customers.length;
  
  // Calculate average project duration
  const completedProjects = projects.filter(p => p.status === 'completed');
  const avgDuration = completedProjects.length ? 
    completedProjects.reduce((sum, p) => {
      const start = new Date(p.startDate);
      const end = new Date(p.completionDate || p.dueDate);
      return sum + (end - start) / (1000 * 60 * 60 * 24);
    }, 0) / completedProjects.length : 0;
  
  // Calculate customer LTV (simplified)
  const totalRevenue = completedProjects.reduce((sum, p) => sum + (p.total || 0), 0);
  const customerLTV = customers.length ? totalRevenue / customers.length : 0;
  
  // Get comparison data
  const comparison = getComparisonData();
  
  // Update UI
  document.getElementById('new-customers').textContent = newCustomers;
  document.getElementById('avg-project-duration').textContent = avgDuration.toFixed(0);
  document.getElementById('customer-ltv').textContent = formatCurrency(customerLTV);
  
  // Update comparison indicators
  updateComparisonIndicator('customer-ltv-change', customerLTV, comparison.lastLTV);
}

function calculateInventoryMetrics(inventory) {
  // Calculate inventory turnover (simplified)
  const totalValue = inventory.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0);
  const cogs = 10000; // This would come from actual COGS data
  const turnover = totalValue ? cogs / totalValue : 0;
  
  // Get comparison data
  const comparison = getComparisonData();
  
  // Update UI
  document.getElementById('inventory-turnover').textContent = turnover.toFixed(1) + 'x';
  
  // Update comparison indicator
  updateComparisonIndicator('inventory-turnover-change', turnover, comparison.lastTurnover, true);
}

function renderInventoryLevels(inventory) {
  const tableBody = document.querySelector('#inventory-table tbody');
  tableBody.innerHTML = inventory.map(item => {
    const statusClass = 
      item.quantity <= item.reorderLevel * 0.3 ? 'inventory-critical' :
      item.quantity <= item.reorderLevel ? 'inventory-low' : 'inventory-adequate';
    
    const statusText = 
      item.quantity <= item.reorderLevel * 0.3 ? 'Critical' :
      item.quantity <= item.reorderLevel ? 'Low' : 'Adequate';
    
    // Calculate turnover rate for this item
    const turnoverRate = item.unitPrice ? (item.monthlyUsage || 0) / (item.quantity * item.unitPrice) * 12 : 0;
    
    return `
      <tr data-critical="${item.quantity <= item.reorderLevel * 0.3}">
        <td>${item.name}</td>
        <td>${item.quantity} ${item.unit}</td>
        <td>${turnoverRate.toFixed(1)}x/yr</td>
        <td><span class="inventory-status ${statusClass}">${statusText}</span></td>
      </tr>
    `;
  }).join('');
}

function renderProjectStatus(projects) {
  const projectsList = document.getElementById('projects-list');
  projectsList.innerHTML = projects.map(project => {
    const dueDate = new Date(project.dueDate);
    const today = new Date();
    const isLate = dueDate < today && project.status !== 'completed';
    const isAtRisk = !isLate && 
      (dueDate - today) / (1000 * 60 * 60 * 24) < 7 && 
      project.status !== 'completed';
    
    const statusClass = isLate ? 'status-late' : 
      isAtRisk ? 'status-at-risk' : 'status-on-time';
    const statusText = isLate ? 'Late' : 
      isAtRisk ? 'At Risk' : 'On Time';
    
    const progress = project.status === 'completed' ? 100 : 
      Math.min(Math.max(project.progress || 0, 0), 100);
    
    return `
      <div class="list-group-item project-item" 
           data-status="${project.status}" 
           data-type="${project.type || 'other'}"
           data-late="${isLate}">
        <div class="d-flex justify-content-between align-items-center">
          <div>
            <h6 class="mb-1">${project.name}</h6>
            <small class="text-muted">${project.type || 'Project'} • Due ${formatDate(project.dueDate)}</small>
          </div>
          <div class="d-flex align-items-center">
            <span class="project-status-indicator ${statusClass}"></span>
            <small class="me-3">${statusText}</small>
            <div class="progress" style="width: 100px; height: 8px;">
              <div class="progress-bar" role="progressbar" style="width: ${progress}%"></div>
            </div>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

function initFinancialChart(transactions, customers) {
  const ctx = document.getElementById('financialChart').getContext('2d');
  
  // Destroy existing chart if it exists
  if (window.financialChart) {
    window.financialChart.destroy();
  }
  
  // Show loading state
  const chartContainer = document.querySelector('#financialChart').parentElement;
  const loadingOverlay = chartContainer.querySelector('.chart-loading-overlay');
  loadingOverlay.style.display = 'flex';
  
  // Simulate loading delay (in real app, this would be data processing)
  setTimeout(() => {
    // Group transactions by time period based on current date range
    const { labels, revenueData, expenseData, profitData } = groupChartData(transactions);
    
    // Create chart
    window.financialChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [
          {
            label: 'Revenue',
            data: revenueData,
            backgroundColor: 'rgba(52, 199, 89, 0.7)',
            borderColor: 'rgba(52, 199, 89, 1)',
            borderWidth: 1
          },
          {
            label: 'Profit',
            data: profitData,
            type: 'line',
            borderColor: 'rgba(0, 113, 227, 1)',
            backgroundColor: 'transparent',
            borderWidth: 2,
            pointBackgroundColor: 'rgba(0, 113, 227, 1)'
          }
        ]
      },
      options: getChartOptions('Revenue & Profit')
    });
    
    // Hide loading overlay
    loadingOverlay.style.display = 'none';
  }, 500);
}

function initCustomerChart(customers) {
  const ctx = document.getElementById('customerChart').getContext('2d');
  
  // Destroy existing chart if it exists
  if (window.customerChart) {
    window.customerChart.destroy();
  }
  
  // Group customers by acquisition period
  const { labels, customerData } = groupCustomerData(customers);
  
  // Create chart
  window.customerChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: 'New Customers',
        data: customerData,
        backgroundColor: 'rgba(0, 113, 227, 0.7)',
        borderColor: 'rgba(0, 113, 227, 1)',
        borderWidth: 1
      }]
    },
    options: getChartOptions('Customer Acquisition')
  });
}

function updateFinancialChart(chartType) {
  if (!window.financialChart) return;
  
  // Show loading state
  const chartContainer = document.querySelector('#financialChart').parentElement;
  const loadingOverlay = chartContainer.querySelector('.chart-loading-overlay');
  loadingOverlay.style.display = 'flex';
  
  // Simulate loading delay
  setTimeout(() => {
    // This would use real data in a production app
    switch(chartType) {
      case 'revenue-profit':
        window.financialChart.data.datasets = [
          {
            label: 'Revenue',
            data: [1200, 1900, 1500, 2000, 1800, 2200],
            backgroundColor: 'rgba(52, 199, 89, 0.7)',
            borderColor: 'rgba(52, 199, 89, 1)',
            borderWidth: 1
          },
          {
            label: 'Profit',
            data: [400, 800, 600, 800, 800, 900],
            type: 'line',
            borderColor: 'rgba(0, 113, 227, 1)',
            backgroundColor: 'transparent',
            borderWidth: 2,
            pointBackgroundColor: 'rgba(0, 113, 227, 1)'
          }
        ];
        window.financialChart.options = getChartOptions('Revenue & Profit');
        break;
        
      case 'expenses':
        window.financialChart.data.datasets = [
          {
            label: 'Materials',
            data: [300, 450, 350, 500, 400, 550],
            backgroundColor: 'rgba(0, 113, 227, 0.7)'
          },
          {
            label: 'Labor',
            data: [200, 250, 300, 350, 300, 400],
            backgroundColor: 'rgba(255, 149, 0, 0.7)'
          },
          {
            label: 'Other',
            data: [100, 150, 100, 200, 150, 250],
            backgroundColor: 'rgba(255, 59, 48, 0.7)'
          }
        ];
        window.financialChart.options = getChartOptions('Expenses Breakdown', true);
        break;
        
      case 'cashflow':
        window.financialChart.data.datasets = [
          {
            label: 'Cash In',
            data: [1200, 1900, 1500, 2000, 1800, 2200],
            backgroundColor: 'rgba(52, 199, 89, 0.7)'
          },
          {
            label: 'Cash Out',
            data: [800, 1100, 900, 1200, 1000, 1300],
            backgroundColor: 'rgba(255, 59, 48, 0.7)'
          }
        ];
        window.financialChart.options = getChartOptions('Cash Flow');
        break;
        
      case 'customer-ltv':
        window.financialChart.data.datasets = [
          {
            label: 'Avg. Customer LTV',
            data: [850, 920, 1050, 1100, 1200, 1250],
            type: 'line',
            borderColor: 'rgba(90, 200, 250, 1)',
            backgroundColor: 'transparent',
            borderWidth: 2,
            pointBackgroundColor: 'rgba(90, 200, 250, 1)'
          }
        ];
        window.financialChart.options = getChartOptions('Customer LTV Trend');
        break;
    }
    
    window.financialChart.update();
    loadingOverlay.style.display = 'none';
  }, 500);
}

function setupDashboardEventListeners() {
  // Time period filter
  document.querySelectorAll('.time-filter').forEach(btn => {
    btn.addEventListener('click', function() {
      document.querySelectorAll('.time-filter').forEach(b => b.classList.remove('active'));
      this.classList.add('active');
      dashboardState.currentDateRange = this.dataset.period;
      refreshDashboardData();
    });
  });
  
  // Chart type selector
  document.querySelectorAll('.chart-option').forEach(option => {
    option.addEventListener('click', function(e) {
      e.preventDefault();
      document.querySelectorAll('.chart-option').forEach(o => o.classList.remove('active'));
      this.classList.add('active');
      updateFinancialChart(this.dataset.type);
    });
  });
  
  // Customer segment filter
  document.querySelectorAll('.segment-filter').forEach(option => {
    option.addEventListener('click', function(e) {
      e.preventDefault();
      document.querySelectorAll('.segment-filter').forEach(o => o.classList.remove('active'));
      this.classList.add('active');
      dashboardState.customerSegment = this.dataset.segment;
      refreshDashboardData();
    });
  });
  
  // Project filter
  document.querySelectorAll('.filter-option').forEach(option => {
    option.addEventListener('click', function(e) {
      e.preventDefault();
      
      if (this.dataset.status) {
        document.querySelectorAll('[data-status]').forEach(o => o.classList.remove('active'));
        this.classList.add('active');
        dashboardState.projectFilter = this.dataset.status;
      } else if (this.dataset.type) {
        document.querySelectorAll('[data-type]').forEach(o => o.classList.remove('active'));
        this.classList.add('active');
        dashboardState.projectType = this.dataset.type;
      }
      
      filterProjects();
    });
  });
  
  // Refresh inventory button
  document.getElementById('refresh-inventory').addEventListener('click', async () => {
    const inventory = await getAllRecords('inventory');
    renderInventoryLevels(inventory);
  });
  
  // Critical inventory alert button
  document.getElementById('critical-inventory-alert').addEventListener('click', () => {
    const criticalItems = document.querySelectorAll('#inventory-table tbody tr[data-critical="true"]');
    if (criticalItems.length > 0) {
      showNotification(`${criticalItems.length} critical inventory items need attention`, 'danger');
    } else {
      showNotification('No critical inventory items', 'success');
    }
  });
  
  // Export buttons
  document.getElementById('export-pdf').addEventListener('click', exportDashboardToPDF);
  document.getElementById('export-excel').addEventListener('click', exportDashboardToExcel);
  document.getElementById('export-csv').addEventListener('click', exportDashboardToCSV);
}

// Date range handling
function handleDateRangeChange(startDate, endDate) {
  dashboardState.customStartDate = startDate;
  dashboardState.customEndDate = endDate;
  dashboardState.currentDateRange = 'custom';
  refreshDashboardData();
}

function getDateRange(rangeType) {
  const now = new Date();
  const start = new Date(now);
  const end = new Date(now);
  
  switch(rangeType) {
    case 'week':
      start.setDate(now.getDate() - now.getDay());
      break;
    case 'month':
      start.setDate(1);
      break;
    case 'quarter':
      start.setMonth(Math.floor(now.getMonth() / 3) * 3, 1);
      break;
    case 'year':
      start.setMonth(0, 1);
      break;
    case 'custom':
      return {
        start: dashboardState.customStartDate,
        end: dashboardState.customEndDate
      };
    default: // 'month' as default
      start.setDate(1);
  }
  
  start.setHours(0, 0, 0, 0);
  end.setHours(23, 59, 59, 999);
  
  return { start, end };
}

// Data grouping for charts
function groupChartData(transactions) {
  const { start, end } = getDateRange(dashboardState.currentDateRange);
  const diffTime = Math.abs(end - start);
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  let groupBy;
  let dateFormat;
  
  if (diffDays <= 7) {
    groupBy = 'day';
    dateFormat = { weekday: 'short' };
  } else if (diffDays <= 31) {
    groupBy = 'day';
    dateFormat = { day: 'numeric', month: 'short' };
  } else if (diffDays <= 365) {
    groupBy = 'month';
    dateFormat = { month: 'short' };
  } else {
    groupBy = 'month';
    dateFormat = { month: 'short', year: 'numeric' };
  }
  
  // Group transactions
  const groups = {};
  transactions.forEach(t => {
    const date = new Date(t.date);
    let key;
    
    if (groupBy === 'day') {
      key = date.toLocaleDateString('en', { day: 'numeric', month: 'short' });
    } else {
      key = date.toLocaleDateString('en', { month: 'short' });
    }
    
    if (!groups[key]) {
      groups[key] = { revenue: 0, expenses: 0 };
    }
    
    if (t.type === 'income') {
      groups[key].revenue += t.amount;
    } else {
      groups[key].expenses += t.amount;
    }
  });
  
  // Create sorted labels and data
  const labels = Object.keys(groups).sort((a, b) => {
    return new Date(a) - new Date(b);
  });
  
  const revenueData = labels.map(label => groups[label].revenue);
  const expenseData = labels.map(label => groups[label].expenses);
  const profitData = labels.map(label => groups[label].revenue - groups[label].expenses);
  
  return { labels, revenueData, expenseData, profitData };
}

function groupCustomerData(customers) {
  // Get last 6 periods based on current date range
  const periods = [];
  const { start } = getDateRange(dashboardState.currentDateRange);
  const now = new Date();
  
  let date = new Date(start);
  let format;
  let increment;
  
  if (dashboardState.currentDateRange === 'week' || dashboardState.currentDateRange === 'day') {
    // Group by day for short ranges
    format = { weekday: 'short' };
    increment = () => date.setDate(date.getDate() + 1);
  } else if (dashboardState.currentDateRange === 'month' || dashboardState.currentDateRange === 'custom') {
    // Group by week for medium ranges
    format = { month: 'short', day: 'numeric' };
    increment = () => date.setDate(date.getDate() + 7);
  } else {
    // Group by month for long ranges
    format = { month: 'short' };
    increment = () => date.setMonth(date.getMonth() + 1);
  }
  
  while (date <= now && periods.length < 6) {
    periods.push(date.toLocaleDateString('en', format));
    increment();
  }
  
  // Count customers per period (simplified - would use actual join dates)
  const customerData = periods.map((_, i) => Math.floor(Math.random() * 10) + 2);
  
  return { labels: periods, customerData };
}

// Filtering functions
async function getFilteredProjects() {
  const allProjects = await getAllRecords('projects');
  
  return allProjects.filter(project => {
    // Apply status filter
    if (dashboardState.projectFilter === 'active' && project.status === 'completed') {
      return false;
    }
    if (dashboardState.projectFilter === 'late') {
      const dueDate = new Date(project.dueDate);
      const today = new Date();
      if (dueDate >= today || project.status === 'completed') {
        return false;
      }
    }
    
    // Apply type filter
    if (dashboardState.projectType !== 'all' && project.type !== dashboardState.projectType) {
      return false;
    }
    
    // Apply date range filter
    if (dashboardState.currentDateRange !== 'all') {
      const { start, end } = getDateRange(dashboardState.currentDateRange);
      const projectDate = new Date(project.startDate);
      if (projectDate < start || projectDate > end) {
        return false;
      }
    }
    
    return true;
  });
}

async function getFilteredCustomers() {
  const allCustomers = await getAllRecords('customers');
  
  return allCustomers.filter(customer => {
    // Apply segment filter
    if (dashboardState.customerSegment === 'residential' && customer.type !== 'residential') {
      return false;
    }
    if (dashboardState.customerSegment === 'commercial' && customer.type !== 'commercial') {
      return false;
    }
    if (dashboardState.customerSegment === 'repeat' && !customer.isRepeat) {
      return false;
    }
    
    // Apply date range filter
    if (dashboardState.currentDateRange !== 'all') {
      const { start, end } = getDateRange(dashboardState.currentDateRange);
      const joinDate = new Date(customer.joinDate);
      if (joinDate < start || joinDate > end) {
        return false;
      }
    }
    
    return true;
  });
}

function filterProjects() {
  const projectItems = document.querySelectorAll('#projects-list .project-item');
  
  projectItems.forEach(item => {
    const statusMatch = 
      dashboardState.projectFilter === 'all' ||
      (dashboardState.projectFilter === 'active' && item.dataset.status !== 'completed') ||
      (dashboardState.projectFilter === 'late' && item.dataset.late === 'true');
    
    const typeMatch = 
      dashboardState.projectType === 'all' ||
      item.dataset.type === dashboardState.projectType;
    
    item.style.display = statusMatch && typeMatch ? 'block' : 'none';
  });
}

// Comparison data helpers
function getComparisonData() {
  // In a real app, this would fetch data for the previous period
  // For this example, we'll return mock data
  return {
    lastRevenue: 11000,
    lastNetProfit: 8100,
    lastExpensesRatio: 30,
    lastLTV: 1190,
    lastTurnover: 4.5
  };
}

function updateComparisonIndicator(elementId, currentValue, previousValue, invertColors = false) {
  const element = document.getElementById(elementId);
  if (!element) return;
  
  if (previousValue === 0 || previousValue === undefined) {
    element.textContent = 'No previous data';
    element.className = 'text-muted';
    return;
  }
  
  const change = ((currentValue - previousValue) / previousValue) * 100;
  const absChange = Math.abs(change);
  
  let direction, color;
  
  if (invertColors) {
    direction = change <= 0 ? '↑' : '↓';
    color = change <= 0 ? 'success' : 'danger';
  } else {
    direction = change >= 0 ? '↑' : '↓';
    color = change >= 0 ? 'success' : 'danger';
  }
  
  element.textContent = `${direction} ${absChange.toFixed(1)}% from last period`;
  element.className = `text-${color}`;
}

// Notification functions
function checkForCriticalNotifications(inventory, projects) {
  // Check for critical inventory
  const criticalInventory = inventory.filter(item => item.quantity <= item.reorderLevel * 0.3);
  if (criticalInventory.length > 0) {
    showNotification(
      `${criticalInventory.length} inventory items at critical levels`,
      'danger',
      'inventory-critical'
    );
  }
  
  // Check for late projects
  const lateProjects = projects.filter(p => {
    const dueDate = new Date(p.dueDate);
    const today = new Date();
    return dueDate < today && p.status !== 'completed';
  });
  
  if (lateProjects.length > 0) {
    showNotification(
      `${lateProjects.length} projects are late`,
      'warning',
      'projects-late'
    );
  }
  
  // Update notification badge
  updateNotificationBadge(criticalInventory.length + lateProjects.length);
}

function updateNotificationBadge(count) {
  const badge = document.getElementById('notification-badge');
  if (badge) {
    badge.textContent = count;
    badge.style.display = count > 0 ? 'flex' : 'none';
  }
}

// Milestone functions
function checkForMilestones() {
  // In a real app, this would check actual business metrics
  // For this example, we'll use random milestones
  
  if (Math.random() > 0.7) {
    const milestones = [
      {
        title: "Revenue Milestone!",
        description: "Your workshop has reached $50,000 in total revenue!",
        icon: "bi-currency-dollar"
      },
      {
        title: "Customer Achievement",
        description: "You've served 100 customers this year!",
        icon: "bi-people-fill"
      },
      {
        title: "Efficiency Improvement",
        description: "Project completion time reduced by 15% this quarter!",
        icon: "bi-speedometer2"
      }
    ];
    
    const milestone = milestones[Math.floor(Math.random() * milestones.length)];
    showMilestone(milestone.title, milestone.description, milestone.icon);
  }
}

function showMilestone(title, description, icon) {
  const modal = new bootstrap.Modal(document.getElementById('milestoneModal'));
  document.getElementById('milestone-title').textContent = title;
  document.getElementById('milestone-description').textContent = description;
  
  const iconElement = document.querySelector('#milestoneModal .milestone-icon i');
  if (iconElement) {
    iconElement.className = `bi ${icon}`;
  }
  
  modal.show();
}

// Export functions
async function exportDashboardToPDF() {
  showLoadingIndicator();
  try {
    // Capture current date range for the report title
    const dateRange = dashboardState.currentDateRange === 'custom' ? 
      `${formatDate(dashboardState.customStartDate)} - ${formatDate(dashboardState.customEndDate)}` :
      `This ${dashboardState.currentDateRange}`;
    
    // Get current data for export
    const [transactions, projects, inventory, customers] = await Promise.all([
      getRecordsByDateRange('transactions', getDateRange(dashboardState.currentDateRange).start, 
      getDateRange(dashboardState.currentDateRange).end),
      getFilteredProjects(),
      getAllRecords('inventory'),
      getFilteredCustomers()
    ]);
    
    // Generate PDF (this would call your actual PDF generation function)
    await exportToPDF({
      title: `Workshop Dashboard Report - ${dateRange}`,
      dateRange,
      financialData: calculateFinancialData(transactions),
      customerMetrics: calculateCustomerMetricsData(customers, projects),
      inventoryStatus: inventory,
      projectsStatus: projects
    });
    
    showNotification('PDF report generated successfully', 'success');
  } catch (error) {
    console.error('Error generating PDF:', error);
    showNotification('Failed to generate PDF report', 'danger');
  } finally {
    hideLoadingIndicator();
  }
}

async function exportDashboardToExcel() {
  showLoadingIndicator();
  try {
    // Get current data for export
    const [transactions, projects, inventory, customers] = await Promise.all([
      getRecordsByDateRange('transactions', getDateRange(dashboardState.currentDateRange).start, 
      getDateRange(dashboardState.currentDateRange).end),
      getFilteredProjects(),
      getAllRecords('inventory'),
      getFilteredCustomers()
    ]);
    
    // Prepare data for Excel export
    const data = {
      'Financial Data': prepareFinancialDataForExport(transactions),
      'Customer Metrics': prepareCustomerDataForExport(customers),
      'Inventory Status': prepareInventoryDataForExport(inventory),
      'Project Status': prepareProjectDataForExport(projects)
    };
    
    // Generate Excel file
    await exportToExcel(data, `Workshop_Dashboard_${new Date().toISOString().slice(0, 10)}`);
    
    showNotification('Excel export completed successfully', 'success');
  } catch (error) {
    console.error('Error exporting to Excel:', error);
    showNotification('Failed to export to Excel', 'danger');
  } finally {
    hideLoadingIndicator();
  }
}

async function exportDashboardToCSV() {
  showLoadingIndicator();
  try {
    // Get current data for export
    const transactions = await getRecordsByDateRange('transactions', 
      getDateRange(dashboardState.currentDateRange).start, 
      getDateRange(dashboardState.currentDateRange).end);
    
    // Generate CSV file
    await exportToCSV(transactions, 'transactions', `Transactions_${new Date().toISOString().slice(0, 10)}`);
    
    showNotification('CSV export completed successfully', 'success');
  } catch (error) {
    console.error('Error exporting to CSV:', error);
    showNotification('Failed to export to CSV', 'danger');
  } finally {
    hideLoadingIndicator();
  }
}

// UI helpers
function showLoadingIndicator() {
  const indicator = document.getElementById('refresh-indicator');
  if (indicator) {
    indicator.style.display = 'flex';
  }
}

function hideLoadingIndicator() {
  const indicator = document.getElementById('refresh-indicator');
  if (indicator) {
    indicator.style.display = 'none';
  }
}

function updateLastUpdatedTime() {
  // This would update a "Last updated" timestamp on the dashboard
  console.log('Dashboard last updated:', dashboardState.lastUpdated);
}

function getChartOptions(title, stacked = false) {
  return {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: title,
        font: {
          size: 14
        }
      },
      tooltip: {
        callbacks: {
          label: function(context) {
            let label = context.dataset.label || '';
            if (label) {
              label += ': ';
            }
            if (context.parsed.y !== null) {
              label += formatCurrency(context.parsed.y);
            }
            return label;
          }
        }
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        stacked: stacked,
        ticks: {
          callback: function(value) {
            return formatCurrency(value);
          }
        }
      },
      x: {
        stacked: stacked
      }
    },
    animation: {
      duration: 1000
    }
  };
}